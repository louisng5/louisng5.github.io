The icons are generated from https://fontello.com/


star        - Font Awesome, star-empty  - e800
rss         - Font Awesome, rss         - e801
posts       - Font Awesome, doc-text    - e802
location    - Font Awesome, location    - e803
link        - Entypo, link              - e804
googleplus  - Entypo, gplus             - e805
facebook    - Entypo, facebook          - e806
arrow-right - Entypo, right-open-big    - e807
arrow-left  - Entypo, left-open-big     - e808
twitter     - Entypo, twitter           - e809
menu        - Font Awesome, menu        - e80a
globe       - Font Awesome, globe       - e80b
search      - Font Awesome, search      - e80c
linkedin    - Entypo, linkedin          - e80d
github      - Zocial, github-circled    - e80e
reddit      - Font Awesome, reddit-alien- e80f
mail        - Font Awesome, mail        - e816
